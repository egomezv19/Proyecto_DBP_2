package com.example.backend.trabajador.domain;

import org.springframework.data.jpa.repository.JpaRepository;

public interface IngenieroVueloRepository extends JpaRepository<IngenieroVuelo, Long> {
    
}
