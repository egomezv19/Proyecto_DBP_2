package com.example.backend.trabajador.domain;

import jakarta.persistence.*;

@Entity
@Table(name = "directorvuelo" )
public class DirectorVuelo extends Trabajador {

    public DirectorVuelo(){}

}