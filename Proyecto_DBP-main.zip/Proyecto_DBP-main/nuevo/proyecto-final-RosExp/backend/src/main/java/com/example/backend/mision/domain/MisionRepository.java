package com.example.backend.mision.domain;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MisionRepository extends JpaRepository<Mision, Long> {}

    

