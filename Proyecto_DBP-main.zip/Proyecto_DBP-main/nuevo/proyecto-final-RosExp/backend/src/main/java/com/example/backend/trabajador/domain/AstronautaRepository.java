package com.example.backend.trabajador.domain;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AstronautaRepository extends JpaRepository<Astronauta, Long>{
    
}
