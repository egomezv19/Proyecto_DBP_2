package com.example.backend.cohete.domain;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CoheteRepository extends JpaRepository<Cohete, Long> {
    
}